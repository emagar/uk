Constituency-Level Elections Archive (CLEA)
Website: http://www.electiondataarchive.org
Email:   clea-project@umich.edu

Dataset and Codebook 
October 24, 2016 Version (20161024)

FILES: 

readme_clea_20161024_r.txt - this file

clea_201620161024.rdata   - R RData file (which can be read into R directly), created with Stat/Transfer ver.13.2.635.0918


IMPORTANT NOTE:

The codebook and documentation can be found with the main dataset (clea_20161024.zip).